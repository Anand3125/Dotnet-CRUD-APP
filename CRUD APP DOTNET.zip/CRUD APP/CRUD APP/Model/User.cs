﻿namespace CRUD_APP.Model
{
    public class User
    {
        public int ID { get; set; }
        public int Name { get; set; }
        public int Email { get; set; }


    }
}
